Dart2JS is the Dart-to-JavaScript compiler for Dart. This compiler
will provide high-quality translation from Dart to JavaScript.

Some areas that will explored in this project are:

   * high-performance extensible scanner and parser
   * concrete type inferencing
   * fancy language tool support
   * programming environment integration
   * SSA-based intermediate representation
   * adaptive compilation on the client

